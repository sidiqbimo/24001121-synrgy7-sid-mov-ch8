package com.bimobelajar.mymovie.ui.login

class LoginViewModel {
}